# Rainbow-Rank-for-Discord
Bot for a colour changing name in discord.

Warning: Can get you IP banned from discord, I would advise not using.

Made with the discord.js library.
https://github.com/hydrabolt/discord.js/


